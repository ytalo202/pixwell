/** RUBY LAZYLOAD IMAGES */
var RB_LAZY_LOAD = (function (Module, $) {
    "use strict";

    Module.init = function () {
        var self = this;
        var $window = $(window);
        $window.on('load RB:LazyLoad', function () {
            var imageData = $('.rb-lazyload');
            self.loadImages(imageData);
            self.reloadSizes(imageData);
        });
    };

    Module.loadImages = function (imageData) {
        var self = this;
        imageData.imagesLoaded().progress(function (instance, image) {
            var imgObject = $(image.img);
            if (!imgObject.hasClass('lazy-loaded')) {
                self.parseImage(imgObject);
            }
        });
    };

    Module.parseImage = function (imgObject) {
        if (imgObject.hasClass('rb-autosize')) {
            imgObject.attr('sizes', this.getWidth(imgObject));
        } else {
            imgObject.attr('sizes', imgObject.data('sizes'));
        }

        imgObject.removeClass('lazyload').addClass('lazy-loading');
        imgObject.attr('srcset', imgObject.data('srcset'));
        setTimeout(function () {
            imgObject.attr('src', imgObject.data('src')).removeClass('lazy-loading').addClass('lazy-loaded');
            imgObject.removeAttr('style');
        }, 10);
    };

    Module.getWidth = function (imgObject) {
        var width = imgObject.parent().width();
        if (!width) {
            width = imgObject.data('sizes');
        } else {
            width += 'px';
        }
        return width;
    };

    Module.reloadSizes = function (imageData) {
        var self = this;
        $(window).resize(function () {
            imageData.each(function () {
                var imgObject = $(this);
                imgObject.attr('sizes', self.getWidth(imgObject));
            });
        })
    };

    return Module;

}(RB_LAZY_LOAD || {}, jQuery));


jQuery(document).ready(function () {
    RB_LAZY_LOAD.init();
});

<?php
/** render cookie popup */
add_action( 'wp_footer', 'rb_render_cookie_popup' );
if ( ! function_exists( 'rb_render_cookie_popup' ) ) :
	function rb_render_cookie_popup() {
		$popup = pixwell_get_option( 'cookie_popup' );
		if ( empty( $popup ) ) {
			return;
		}
		$content = pixwell_get_option( 'cookie_popup_content' );
		$button  = pixwell_get_option( 'cookie_popup_button' ); ?>
		<aside id="rb-cookie" class="rb-cookie">
			<p class="cookie-content"><?php echo do_shortcode( $content ); ?></p>
			<div class="cookie-footer">
				<a id="cookie-accept" class="cookie-accept" href="#"><?php echo esc_html( $button ) ?></a>
			</div>
		</aside>
	<?php
	}
endif;
